Automatic Machine Learning Wrapper Library

----------------------------------------------

1)Automatic sampling method on big datasets

2)Automatic feature type method on big datasets

3)Automatic missing values handling

4)Automatic algorithm detection

5)Automatic algorithm hyper-parameter detection
